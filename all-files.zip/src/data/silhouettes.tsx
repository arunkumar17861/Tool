import React from 'react';
import { ComparisonSubject } from '../types';

interface SilhouetteProps {
  subject: ComparisonSubject;
  className?: string;
}

export const SilhouetteRenderer: React.FC<SilhouetteProps> = ({ subject, className = '' }) => {
  const { category, genderStyle, objectPresetKey, color, customImageUrl, customShape } = subject;

  // Custom transparent uploaded image
  if (customImageUrl) {
    return (
      <div className={`w-full h-full flex items-end justify-center ${className}`}>
        <img
          src={customImageUrl}
          alt={subject.name}
          className="max-h-full max-w-full object-contain filter drop-shadow-sm select-none pointer-events-none"
          style={{ objectPosition: 'bottom' }}
          referrerPolicy="no-referrer"
        />
      </div>
    );
  }

  // Custom shapes
  if (category === 'custom' || customShape) {
    if (customShape === 'circle') {
      return (
        <svg viewBox="0 0 100 100" preserveAspectRatio="none" className={`w-full h-full ${className}`}>
          <circle cx="50" cy="50" r="48" fill={color} />
        </svg>
      );
    }
    if (customShape === 'cylinder') {
      return (
        <svg viewBox="0 0 100 100" preserveAspectRatio="none" className={`w-full h-full ${className}`}>
          <path
            d="M 10 15 
               A 40 10 0 0 0 90 15 
               A 40 10 0 0 0 10 15 
               V 85 
               A 40 10 0 0 0 90 85 
               V 15 
               Z"
            fill={color}
          />
        </svg>
      );
    }
    // Default rect
    return (
      <div 
        className={`w-full h-full rounded-sm border border-black/10 shadow-sm ${className}`}
        style={{ backgroundColor: color }}
      />
    );
  }

  // OBJECTS & VEHICLES & ANIMALS
  if (category === 'object' || category === 'vehicle' || category === 'animal' || category === 'landmark' || objectPresetKey) {
    switch (objectPresetKey) {
      case 'door':
        return (
          <svg viewBox="0 0 100 200" preserveAspectRatio="none" className={`w-full h-full ${className}`}>
            {/* Outer frame */}
            <rect x="5" y="2" width="90" height="196" fill="#44403c" rx="1" />
            {/* Door slab */}
            <rect x="10" y="6" width="80" height="190" fill={color} />
            {/* Top panel inset */}
            <rect x="20" y="20" width="60" height="65" fill="#000000" fillOpacity="0.12" rx="2" />
            {/* Bottom panel inset */}
            <rect x="20" y="95" width="60" height="85" fill="#000000" fillOpacity="0.12" rx="2" />
            {/* Handle & lock */}
            <circle cx="22" cy="105" r="4" fill="#fbbf24" />
            <rect x="19" y="102" width="10" height="3" rx="1" fill="#f59e0b" />
          </svg>
        );

      case 'refrigerator':
        return (
          <svg viewBox="0 0 90 180" preserveAspectRatio="none" className={`w-full h-full ${className}`}>
            {/* Fridge body */}
            <rect x="4" y="4" width="82" height="172" rx="4" fill={color} />
            {/* Freezer door line */}
            <line x1="4" y1="65" x2="86" y2="65" stroke="#000000" strokeWidth="2" strokeOpacity="0.25" />
            {/* Door handles */}
            <rect x="12" y="30" width="3" height="25" rx="1.5" fill="#ffffff" fillOpacity="0.8" />
            <rect x="12" y="75" width="3" height="40" rx="1.5" fill="#ffffff" fillOpacity="0.8" />
            {/* Water dispenser */}
            <rect x="55" y="25" width="18" height="25" rx="2" fill="#000000" fillOpacity="0.2" />
          </svg>
        );

      case 'wardrobe':
        return (
          <svg viewBox="0 0 110 200" preserveAspectRatio="none" className={`w-full h-full ${className}`}>
            <rect x="5" y="5" width="100" height="190" rx="2" fill={color} />
            {/* Center seam */}
            <line x1="55" y1="5" x2="55" y2="195" stroke="#000000" strokeWidth="2" strokeOpacity="0.3" />
            {/* Handles */}
            <rect x="48" y="95" width="3" height="18" rx="1" fill="#e2e8f0" />
            <rect x="59" y="95" width="3" height="18" rx="1" fill="#e2e8f0" />
            {/* Crown molding top */}
            <rect x="3" y="2" width="104" height="6" fill="#000000" fillOpacity="0.2" rx="1" />
          </svg>
        );

      case 'table':
        return (
          <svg viewBox="0 0 140 80" preserveAspectRatio="none" className={`w-full h-full ${className}`}>
            {/* Tabletop */}
            <rect x="4" y="2" width="132" height="10" rx="2" fill={color} />
            {/* Legs */}
            <rect x="10" y="12" width="8" height="66" fill={color} />
            <rect x="122" y="12" width="8" height="66" fill={color} />
            <rect x="22" y="12" width="6" height="66" fill="#000000" fillOpacity="0.2" />
            <rect x="112" y="12" width="6" height="66" fill="#000000" fillOpacity="0.2" />
            {/* Apron */}
            <rect x="10" y="12" width="120" height="6" fill="#000000" fillOpacity="0.15" />
          </svg>
        );

      case 'chair':
        return (
          <svg viewBox="0 0 60 90" preserveAspectRatio="none" className={`w-full h-full ${className}`}>
            {/* Backrest */}
            <rect x="8" y="4" width="8" height="45" rx="2" fill={color} />
            {/* Seat */}
            <rect x="8" y="45" width="44" height="6" rx="2" fill={color} />
            {/* Front & Back Legs */}
            <rect x="10" y="51" width="5" height="37" fill={color} />
            <rect x="44" y="51" width="5" height="37" fill={color} />
            {/* Crossbar */}
            <rect x="10" y="65" width="39" height="3" fill="#000000" fillOpacity="0.2" />
          </svg>
        );

      case 'couch':
        return (
          <svg viewBox="0 0 160 85" preserveAspectRatio="none" className={`w-full h-full ${className}`}>
            {/* Backrest */}
            <rect x="10" y="4" width="140" height="42" rx="8" fill={color} />
            {/* Left Armrest */}
            <rect x="4" y="24" width="22" height="48" rx="6" fill={color} />
            {/* Right Armrest */}
            <rect x="134" y="24" width="22" height="48" rx="6" fill={color} />
            {/* Seat Cushions */}
            <rect x="24" y="42" width="112" height="30" rx="4" fill="#000000" fillOpacity="0.15" />
            {/* Feet */}
            <rect x="12" y="74" width="8" height="9" fill="#292524" rx="1" />
            <rect x="140" y="74" width="8" height="9" fill="#292524" rx="1" />
          </svg>
        );

      case 'bicycle':
        return (
          <svg viewBox="0 0 160 100" preserveAspectRatio="none" className={`w-full h-full ${className}`}>
            {/* Wheels */}
            <circle cx="32" cy="70" r="26" fill="none" stroke={color} strokeWidth="5" />
            <circle cx="32" cy="70" r="5" fill={color} />
            <circle cx="128" cy="70" r="26" fill="none" stroke={color} strokeWidth="5" />
            <circle cx="128" cy="70" r="5" fill={color} />
            {/* Frame tubes */}
            <line x1="32" y1="70" x2="75" y2="70" stroke={color} strokeWidth="5" strokeLinecap="round" />
            <line x1="75" y1="70" x2="65" y2="35" stroke={color} strokeWidth="5" strokeLinecap="round" />
            <line x1="32" y1="70" x2="65" y2="35" stroke={color} strokeWidth="5" strokeLinecap="round" />
            <line x1="65" y1="35" x2="115" y2="35" stroke={color} strokeWidth="5" strokeLinecap="round" />
            <line x1="75" y1="70" x2="115" y2="35" stroke={color} strokeWidth="5" strokeLinecap="round" />
            <line x1="128" y1="70" x2="120" y2="20" stroke={color} strokeWidth="5" strokeLinecap="round" />
            {/* Handlebars & Seat */}
            <line x1="110" y1="18" x2="130" y2="18" stroke={color} strokeWidth="5" strokeLinecap="round" />
            <rect x="55" y="28" width="22" height="6" rx="3" fill="#1e293b" />
          </svg>
        );

      case 'car':
        return (
          <svg viewBox="0 0 200 80" preserveAspectRatio="none" className={`w-full h-full ${className}`}>
            {/* Car body */}
            <path
              d="M 15 50 
                 L 35 32 
                 L 68 12 
                 L 132 12 
                 L 165 32 
                 L 190 38 
                 C 195 42 195 56 190 58 
                 L 15 58 
                 Z"
              fill={color}
            />
            {/* Windows */}
            <path
              d="M 42 32 
                 L 69 16 
                 L 96 16 
                 L 96 32 
                 Z"
              fill="#ffffff"
              fillOpacity="0.65"
            />
            <path
              d="M 102 16 
                 L 130 16 
                 L 158 32 
                 L 102 32 
                 Z"
              fill="#ffffff"
              fillOpacity="0.65"
            />
            {/* Wheels */}
            <circle cx="50" cy="58" r="16" fill="#1e293b" />
            <circle cx="50" cy="58" r="8" fill="#94a3b8" />
            <circle cx="150" cy="58" r="16" fill="#1e293b" />
            <circle cx="150" cy="58" r="8" fill="#94a3b8" />
          </svg>
        );

      case 'bus':
        return (
          <svg viewBox="0 0 240 100" preserveAspectRatio="none" className={`w-full h-full ${className}`}>
            {/* Bus body */}
            <rect x="10" y="10" width="220" height="72" rx="8" fill={color} />
            {/* Windows row */}
            <rect x="25" y="20" width="28" height="25" rx="3" fill="#ffffff" fillOpacity="0.75" />
            <rect x="60" y="20" width="32" height="25" rx="3" fill="#ffffff" fillOpacity="0.75" />
            <rect x="98" y="20" width="32" height="25" rx="3" fill="#ffffff" fillOpacity="0.75" />
            <rect x="136" y="20" width="32" height="25" rx="3" fill="#ffffff" fillOpacity="0.75" />
            <rect x="174" y="20" width="40" height="25" rx="3" fill="#ffffff" fillOpacity="0.75" />
            {/* Front windshield */}
            <path d="M 218 20 L 226 22 L 226 45 L 218 45 Z" fill="#ffffff" fillOpacity="0.8" />
            {/* Wheels */}
            <circle cx="55" cy="84" r="14" fill="#1e293b" />
            <circle cx="55" cy="84" r="7" fill="#cbd5e1" />
            <circle cx="185" cy="84" r="14" fill="#1e293b" />
            <circle cx="185" cy="84" r="7" fill="#cbd5e1" />
          </svg>
        );

      case 'dog':
        return (
          <svg viewBox="0 0 100 80" preserveAspectRatio="none" className={`w-full h-full ${className}`}>
            {/* Dog silhouette (standing retriever profile) */}
            <path
              d="M 85 10 
                 C 82 8, 76 6, 73 12 
                 C 70 15, 68 20, 62 24 
                 C 55 24, 45 23, 30 28 
                 C 24 30, 18 34, 12 40 
                 C 10 38, 7 32, 5 36 
                 C 2 40, 5 48, 12 50 
                 C 15 54, 18 64, 18 78 
                 L 25 78 
                 C 26 66, 28 62, 35 60 
                 L 58 60 
                 C 62 65, 63 70, 64 78 
                 L 72 78 
                 C 72 65, 75 50, 78 40 
                 C 84 38, 88 34, 94 30 
                 C 97 28, 96 20, 90 20 
                 C 87 20, 87 14, 85 10 
                 Z"
              fill={color}
            />
          </svg>
        );

      case 'cat':
        return (
          <svg viewBox="0 0 60 60" preserveAspectRatio="none" className={`w-full h-full ${className}`}>
            {/* Cat with upright tail */}
            <path
              d="M 12 58 
                 L 16 58 
                 C 17 50, 18 45, 22 44 
                 L 38 44 
                 C 40 48, 42 52, 44 58 
                 L 50 58 
                 C 50 46, 48 38, 46 32 
                 C 48 30, 50 25, 52 20 
                 L 55 12 
                 L 48 16 
                 C 44 14, 40 14, 38 16 
                 L 35 12 
                 L 35 20 
                 C 30 26, 22 30, 15 32 
                 C 10 24, 8 15, 8 8 
                 C 5 8, 4 15, 6 25 
                 C 7 35, 10 48, 12 58 
                 Z"
              fill={color}
            />
          </svg>
        );

      case 'horse':
        return (
          <svg viewBox="0 0 120 100" preserveAspectRatio="none" className={`w-full h-full ${className}`}>
            <path
              d="M 105 10 
                 C 98 6, 92 12, 90 18 
                 C 86 28, 84 35, 72 40 
                 C 60 40, 48 40, 35 44 
                 C 25 48, 18 56, 12 65 
                 C 8 68, 6 82, 10 92 
                 C 13 88, 15 80, 18 78 
                 L 22 98 
                 L 28 98 
                 C 30 84, 32 75, 40 70 
                 L 65 70 
                 C 68 78, 70 88, 72 98 
                 L 78 98 
                 C 80 84, 85 70, 88 56 
                 C 95 48, 102 36, 108 24 
                 C 114 20, 114 14, 105 10 
                 Z"
              fill={color}
            />
          </svg>
        );

      case 'elephant':
        return (
          <svg viewBox="0 0 150 110" preserveAspectRatio="none" className={`w-full h-full ${className}`}>
            <path
              d="M 115 15 
                 C 105 10, 90 10, 75 16 
                 C 55 24, 35 32, 25 45 
                 C 18 55, 15 70, 15 85 
                 L 25 108 
                 L 40 108 
                 C 42 90, 45 80, 55 80 
                 L 80 80 
                 C 82 90, 85 100, 90 108 
                 L 105 108 
                 C 105 88, 108 75, 115 65 
                 C 125 65, 132 58, 138 48 
                 C 142 55, 145 72, 142 85 
                 C 140 92, 135 95, 132 92 
                 C 130 90, 135 78, 132 70 
                 C 128 55, 122 42, 118 30 
                 C 122 25, 122 18, 115 15 
                 Z"
              fill={color}
            />
          </svg>
        );

      case 'giraffe':
        return (
          <svg viewBox="0 0 100 200" preserveAspectRatio="none" className={`w-full h-full ${className}`}>
            <path
              d="M 85 6 
                 C 82 4, 76 5, 74 10 
                 C 72 15, 68 40, 62 80 
                 C 58 100, 52 118, 40 128 
                 C 32 135, 22 142, 18 152 
                 L 22 198 
                 L 28 198 
                 C 30 178, 35 165, 45 160 
                 L 58 160 
                 C 62 172, 65 185, 68 198 
                 L 74 198 
                 C 76 172, 78 145, 82 128 
                 C 88 115, 92 80, 94 40 
                 C 96 25, 96 15, 92 10 
                 C 90 6, 88 7, 85 6 
                 Z"
              fill={color}
            />
          </svg>
        );

      case 'basketball_hoop':
        return (
          <svg viewBox="0 0 100 220" preserveAspectRatio="none" className={`w-full h-full ${className}`}>
            {/* Pole */}
            <rect x="75" y="40" width="8" height="178" fill="#475569" />
            <path d="M 60 218 L 98 218 L 88 195 L 70 195 Z" fill="#334155" />
            {/* Boom arm */}
            <line x1="75" y1="55" x2="35" y2="45" stroke="#475569" strokeWidth="6" />
            {/* Backboard */}
            <rect x="30" y="20" width="6" height="55" fill="#f8fafc" stroke="#94a3b8" strokeWidth="2" />
            {/* Inner square */}
            <rect x="30" y="38" width="4" height="20" fill="#ea580c" />
            {/* Rim */}
            <line x1="12" y1="52" x2="30" y2="52" stroke="#ea580c" strokeWidth="4" />
            {/* Net */}
            <polygon points="12,52 30,52 26,72 16,72" fill="none" stroke="#e2e8f0" strokeWidth="2" strokeDasharray="2 2" />
          </svg>
        );

      case 'house':
        return (
          <svg viewBox="0 0 120 120" preserveAspectRatio="none" className={`w-full h-full ${className}`}>
            {/* Roof */}
            <polygon points="60,10 10,48 110,48" fill="#e11d48" />
            {/* Chimney */}
            <rect x="85" y="16" width="12" height="22" fill="#78716c" />
            {/* Walls */}
            <rect x="18" y="48" width="84" height="70" fill={color} />
            {/* Door */}
            <rect x="48" y="82" width="24" height="36" fill="#475569" />
            {/* Windows */}
            <rect x="25" y="60" width="18" height="18" fill="#f8fafc" />
            <rect x="77" y="60" width="18" height="18" fill="#f8fafc" />
          </svg>
        );

      case 'statue_of_liberty':
        return (
          <svg viewBox="0 0 80 200" preserveAspectRatio="none" className={`w-full h-full ${className}`}>
            {/* Pedestal */}
            <rect x="15" y="140" width="50" height="58" fill="#78716c" />
            <rect x="10" y="190" width="60" height="8" fill="#57534e" />
            {/* Statue figure */}
            <path
              d="M 40 40 
                 C 38 35, 42 28, 40 22 
                 L 46 10 
                 L 48 10 
                 C 49 18, 48 24, 45 28 
                 C 48 30, 52 35, 52 42 
                 C 55 55, 58 80, 56 110 
                 C 55 125, 54 135, 52 140 
                 L 28 140 
                 C 26 130, 26 115, 28 95 
                 C 30 75, 32 55, 36 45 
                 Z"
              fill={color}
            />
            {/* Torch flame */}
            <circle cx="47" cy="8" r="3" fill="#fbbf24" />
          </svg>
        );

      case 'eiffel_tower':
        return (
          <svg viewBox="0 0 100 240" preserveAspectRatio="none" className={`w-full h-full ${className}`}>
            {/* Spire tip */}
            <line x1="50" y1="4" x2="50" y2="40" stroke={color} strokeWidth="3" />
            {/* Top lantern */}
            <rect x="47" y="40" width="6" height="15" fill={color} />
            {/* Tier 1 platform */}
            <rect x="42" y="90" width="16" height="5" fill={color} />
            {/* Tier 2 platform */}
            <rect x="32" y="150" width="36" height="6" fill={color} />
            {/* Main lattice legs */}
            <path
              d="M 48 55 L 43 90 L 34 150 L 10 238 L 25 238 L 40 165 C 45 155, 55 155, 60 165 L 75 238 L 90 238 L 66 150 L 57 90 L 52 55 Z"
              fill={color}
            />
            {/* Arch bottom */}
            <path d="M 28 238 C 35 195, 65 195, 72 238 Z" fill="#ffffff" fillOpacity="0.2" />
          </svg>
        );

      default:
        // Generic object outline (rounded pillar / pedestal)
        return (
          <svg viewBox="0 0 80 120" preserveAspectRatio="none" className={`w-full h-full ${className}`}>
            <rect x="10" y="10" width="60" height="106" rx="6" fill={color} />
          </svg>
        );
    }
  }

  // HUMAN SILHOUETTES (Clean, proportional anatomical vector figures)
  switch (genderStyle) {
    case 'female':
    case 'athletic_female':
      return (
        <svg viewBox="0 0 80 200" preserveAspectRatio="none" className={`w-full h-full ${className}`}>
          {/* Head & neck */}
          <ellipse cx="40" cy="20" rx="10" ry="13" fill={color} />
          <path d="M 37 32 L 43 32 L 44 42 L 36 42 Z" fill={color} />
          {/* Hair silhouette */}
          <path d="M 30 18 C 30 10, 50 10, 50 18 C 52 28, 48 38, 46 44 C 44 40, 42 35, 40 35 C 38 35, 36 40, 34 44 C 32 38, 28 28, 30 18 Z" fill={color} />
          {/* Torso & hips */}
          <path
            d="M 31 42 
               C 35 41, 45 41, 49 42 
               C 53 46, 56 62, 53 76 
               C 51 86, 54 94, 55 106 
               C 53 108, 47 109, 40 109 
               C 33 109, 27 108, 25 106 
               C 26 94, 29 86, 27 76 
               C 24 62, 27 46, 31 42 
               Z"
            fill={color}
          />
          {/* Arms */}
          <path d="M 28 44 C 23 58, 21 82, 22 104 C 23 108, 26 108, 26 104 C 26 84, 29 60, 31 46 Z" fill={color} />
          <path d="M 52 44 C 57 58, 59 82, 58 104 C 57 108, 54 108, 54 104 C 54 84, 51 60, 49 46 Z" fill={color} />
          {/* Legs & feet (baseline at y=198) */}
          <path
            d="M 28 108 
               C 30 125, 32 150, 33 172 
               C 33 182, 32 192, 28 197 
               L 36 198 
               C 39 193, 38 178, 39 155 
               C 39 135, 39 120, 39 109 
               Z"
            fill={color}
          />
          <path
            d="M 52 108 
               C 50 125, 48 150, 47 172 
               C 47 182, 48 192, 52 197 
               L 44 198 
               C 41 193, 42 178, 41 155 
               C 41 135, 41 120, 41 109 
               Z"
            fill={color}
          />
        </svg>
      );

    case 'child':
      // 8-year-old child: larger head to torso ratio (~1:5.5)
      return (
        <svg viewBox="0 0 70 160" preserveAspectRatio="none" className={`w-full h-full ${className}`}>
          {/* Head */}
          <circle cx="35" cy="22" r="15" fill={color} />
          {/* Torso */}
          <path
            d="M 23 42 
               L 47 42 
               C 48 55, 47 70, 45 88 
               L 25 88 
               C 23 70, 22 55, 23 42 
               Z"
            fill={color}
          />
          {/* Arms */}
          <path d="M 21 44 C 16 55, 14 72, 16 88 L 20 87 C 19 72, 21 55, 24 45 Z" fill={color} />
          <path d="M 49 44 C 54 55, 56 72, 54 88 L 50 87 C 51 72, 49 55, 46 45 Z" fill={color} />
          {/* Legs to ground (y=158) */}
          <path d="M 26 88 L 33 88 L 33 158 L 24 158 C 24 135, 25 110, 26 88 Z" fill={color} />
          <path d="M 44 88 L 37 88 L 37 158 L 46 158 C 46 135, 45 110, 44 88 Z" fill={color} />
        </svg>
      );

    case 'toddler':
      // 2-year-old toddler: prominent head, chubby proportions (~1:4 ratio)
      return (
        <svg viewBox="0 0 60 120" preserveAspectRatio="none" className={`w-full h-full ${className}`}>
          {/* Big head */}
          <circle cx="30" cy="22" r="17" fill={color} />
          {/* Torso / belly */}
          <path
            d="M 18 42 
               C 18 40, 42 40, 42 42 
               C 46 54, 45 68, 40 76 
               L 20 76 
               C 15 68, 14 54, 18 42 
               Z"
            fill={color}
          />
          {/* Little arms */}
          <path d="M 17 44 C 11 50, 9 60, 11 68 L 15 67 C 14 60, 15 52, 19 46 Z" fill={color} />
          <path d="M 43 44 C 49 50, 51 60, 49 68 L 45 67 C 46 60, 45 52, 41 46 Z" fill={color} />
          {/* Legs */}
          <rect x="20" y="76" width="8" height="42" rx="3" fill={color} />
          <rect x="32" y="76" width="8" height="42" rx="3" fill={color} />
          {/* Feet */}
          <rect x="18" y="114" width="11" height="5" rx="2" fill={color} />
          <rect x="31" y="114" width="11" height="5" rx="2" fill={color} />
        </svg>
      );

    case 'athletic_male':
      // V-taper, muscular stance, broad shoulders
      return (
        <svg viewBox="0 0 90 200" preserveAspectRatio="none" className={`w-full h-full ${className}`}>
          {/* Head & neck */}
          <circle cx="45" cy="18" r="11" fill={color} />
          <rect x="42" y="28" width="6" height="12" fill={color} />
          {/* Wide shoulders and V-taper torso */}
          <path
            d="M 23 40 
               L 67 40 
               L 55 96 
               L 35 96 
               Z"
            fill={color}
          />
          {/* Arms */}
          <path d="M 22 41 C 15 58, 13 80, 15 104 C 16 108, 20 108, 20 103 C 20 82, 23 60, 26 44 Z" fill={color} />
          <path d="M 68 41 C 75 58, 77 80, 75 104 C 74 108, 70 108, 70 103 C 70 82, 67 60, 64 44 Z" fill={color} />
          {/* Legs & feet (baseline at y=198) */}
          <path
            d="M 35 96 
               L 44 96 
               L 41 198 
               L 29 198 
               C 31 165, 33 130, 35 96 
               Z"
            fill={color}
          />
          <path
            d="M 55 96 
               L 46 96 
               L 49 198 
               L 61 198 
               C 59 165, 57 130, 55 96 
               Z"
            fill={color}
          />
        </svg>
      );

    case 'teen':
    case 'neutral':
    case 'male':
    default:
      // Adult Male (standard 7.5 heads high, upright stance, feet baseline y=198)
      return (
        <svg viewBox="0 0 80 200" preserveAspectRatio="none" className={`w-full h-full ${className}`}>
          {/* Head & neck */}
          <ellipse cx="40" cy="19" rx="10.5" ry="13.5" fill={color} />
          <rect x="37" y="32" width="6" height="10" fill={color} />
          {/* Torso */}
          <path
            d="M 27 42 
               L 53 42 
               L 49 102 
               L 31 102 
               Z"
            fill={color}
          />
          {/* Arms */}
          <path d="M 26 43 C 20 58, 18 80, 20 104 C 21 107, 24 107, 25 103 C 25 82, 27 60, 30 45 Z" fill={color} />
          <path d="M 54 43 C 60 58, 62 80, 60 104 C 59 107, 56 107, 55 103 C 55 82, 53 60, 50 45 Z" fill={color} />
          {/* Legs & feet */}
          <path
            d="M 31 102 
               L 39 102 
               L 37 198 
               L 26 198 
               C 28 165, 29 135, 31 102 
               Z"
            fill={color}
          />
          <path
            d="M 49 102 
               L 41 102 
               L 43 198 
               L 54 198 
               C 52 165, 51 135, 49 102 
               Z"
            fill={color}
          />
        </svg>
      );
  }
};
