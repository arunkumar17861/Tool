import { ComparisonSubject } from '../types';

interface CompactSubject {
  i: string; // id
  n: string; // name
  h: number; // heightCm
  c: string; // category
  g?: string; // genderStyle
  k?: string; // objectPresetKey
  clr: string; // color
  s?: string; // shape
  v?: number; // isVisible (1 or 0)
}

/**
 * Serializes subjects array into a compressed URL-safe string.
 */
export function encodeComparisonToUrl(subjects: ComparisonSubject[]): string {
  try {
    const compact: CompactSubject[] = subjects.map((s) => ({
      i: s.id,
      n: s.name,
      h: Number(s.heightCm.toFixed(1)),
      c: s.category,
      g: s.genderStyle,
      k: s.objectPresetKey,
      clr: s.color,
      s: s.customShape,
      v: s.isVisible ? 1 : 0,
    }));

    const json = JSON.stringify(compact);
    const base64 = btoa(encodeURIComponent(json));
    const url = new URL(window.location.href);
    url.hash = `c=${base64}`;
    return url.toString();
  } catch (err) {
    console.error('Failed to encode comparison to URL', err);
    return window.location.href;
  }
}

/**
 * Decodes and validates comparison data from current URL or supplied string.
 */
export function decodeComparisonFromUrl(urlOrHash?: string): ComparisonSubject[] | null {
  try {
    const raw = urlOrHash || window.location.hash || window.location.search;
    if (!raw) return null;

    let payload = '';
    if (raw.includes('c=')) {
      const match = raw.match(/c=([^&]+)/);
      if (match && match[1]) {
        payload = match[1];
      }
    }

    if (!payload) return null;

    const json = decodeURIComponent(atob(payload));
    const parsed = JSON.parse(json);

    if (!Array.isArray(parsed) || parsed.length === 0) return null;

    const subjects: ComparisonSubject[] = parsed.map((item: CompactSubject, index: number) => ({
      id: item.i || `subject_${index}_${Date.now()}`,
      name: item.n || 'Unnamed',
      heightCm: typeof item.h === 'number' && item.h > 0 ? item.h : 175,
      category: (['person', 'object', 'animal', 'landmark', 'custom'].includes(item.c)
        ? item.c
        : 'person') as any,
      genderStyle: item.g as any,
      objectPresetKey: item.k,
      color: item.clr || '#3b82f6',
      customShape: item.s as any,
      isVisible: item.v !== 0,
    }));

    return subjects;
  } catch (err) {
    console.warn('Failed to parse comparison state from URL', err);
    return null;
  }
}
