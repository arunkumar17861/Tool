import React from 'react';
import { Sparkles, ArrowRight, Check } from 'lucide-react';
import { SAMPLE_LINEUPS } from '../data/presets';
import { formatBothUnits } from '../utils/measurement';

interface ExampleLineupsProps {
  onLoadLineup: (lineupId: string) => void;
  activeLineupId?: string;
}

export const ExampleLineups: React.FC<ExampleLineupsProps> = ({
  onLoadLineup,
  activeLineupId,
}) => {
  return (
    <section id="lineups" className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 pb-4 dark:border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-50 text-indigo-600 dark:bg-indigo-950/60 dark:text-indigo-400">
            <Sparkles className="h-4 w-4" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Curated Example Lineups
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Explore interesting real-world height comparisons in one click
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {SAMPLE_LINEUPS.map((lineup) => {
          const isActive = activeLineupId === lineup.id;

          return (
            <div
              key={lineup.id}
              className={`flex flex-col justify-between rounded-xl border p-4 transition-all ${
                isActive
                  ? 'border-indigo-600 bg-indigo-50/40 ring-2 ring-indigo-500/20 dark:bg-indigo-950/30'
                  : 'border-slate-200 bg-white hover:border-indigo-300 dark:border-slate-800 dark:bg-slate-900/60'
              }`}
            >
              <div>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                  {lineup.title}
                </h4>
                <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                  {lineup.description}
                </p>

                {/* Subject miniatures */}
                <div className="mt-4 flex items-end gap-1.5 h-16 border-b border-slate-100 pb-2 dark:border-slate-800">
                  {lineup.subjects.map((s) => {
                    const maxH = Math.max(...lineup.subjects.map((sub) => sub.heightCm));
                    const pct = (s.heightCm / maxH) * 100;
                    return (
                      <div
                        key={s.id}
                        className="flex-1 flex flex-col items-center justify-end h-full"
                        title={`${s.name}: ${formatBothUnits(s.heightCm).combined}`}
                      >
                        <div
                          className="w-full rounded-t-sm opacity-90 transition-all hover:opacity-100"
                          style={{
                            height: `${Math.max(12, pct)}%`,
                            backgroundColor: s.color,
                          }}
                        />
                      </div>
                    );
                  })}
                </div>

                <div className="mt-2 text-[11px] text-slate-400">
                  {lineup.subjects.map((s) => s.name.split(' ')[0]).join(' · ')}
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  onClick={() => onLoadLineup(lineup.id)}
                  className={`w-full inline-flex items-center justify-center gap-1.5 rounded-lg py-2 text-xs font-semibold transition-colors ${
                    isActive
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-100 text-slate-700 hover:bg-indigo-600 hover:text-white dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-indigo-600 dark:hover:text-white'
                  }`}
                >
                  {isActive ? (
                    <>
                      <Check className="h-3.5 w-3.5" />
                      Currently Loaded
                    </>
                  ) : (
                    <>
                      Load Lineup
                      <ArrowRight className="h-3.5 w-3.5" />
                    </>
                  )}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
