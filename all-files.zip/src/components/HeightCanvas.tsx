import React, { useRef, useState, useMemo } from 'react';
import { 
  ZoomIn, 
  ZoomOut, 
  RotateCcw, 
  Maximize2, 
  Minimize2, 
  Grid, 
  Eye, 
  EyeOff, 
  ArrowLeft, 
  ArrowRight, 
  Edit3, 
  Copy, 
  Trash2, 
  Sparkles,
  Layers,
  HelpCircle
} from 'lucide-react';
import { ComparisonSubject, CanvasSettings } from '../types';
import { formatBothUnits, cmToFeetAndInches } from '../utils/measurement';
import { SilhouetteRenderer } from '../data/silhouettes';

interface HeightCanvasProps {
  subjects: ComparisonSubject[];
  settings: CanvasSettings;
  onUpdateSettings: (newSettings: Partial<CanvasSettings>) => void;
  onEditSubject: (subject: ComparisonSubject) => void;
  onDuplicateSubject: (subject: ComparisonSubject) => void;
  onToggleSubjectVisibility: (id: string) => void;
  onDeleteSubject: (id: string) => void;
  onMoveSubject: (id: string, direction: 'left' | 'right') => void;
  onOpenAddPerson: () => void;
  onOpenPresets: () => void;
  onLoadLineup: (lineupId: string) => void;
}

export const HeightCanvas: React.FC<HeightCanvasProps> = ({
  subjects,
  settings,
  onUpdateSettings,
  onEditSubject,
  onDuplicateSubject,
  onToggleSubjectVisibility,
  onDeleteSubject,
  onMoveSubject,
  onOpenAddPerson,
  onOpenPresets,
  onLoadLineup,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [hoveredSubjectId, setHoveredSubjectId] = useState<string | null>(null);

  const visibleSubjects = useMemo(() => {
    return subjects.filter((s) => s.isVisible && s.heightCm > 0);
  }, [subjects]);

  // Determine dynamic adaptive scale ceiling (in cm)
  const ceilingCm = useMemo(() => {
    if (visibleSubjects.length === 0) return 220;
    const maxVal = Math.max(...visibleSubjects.map((s) => s.heightCm));
    // Provide comfortable headroom (~15% above tallest figure)
    if (maxVal <= 200) return 220;
    if (maxVal <= 250) return 260;
    if (maxVal <= 350) return 380;
    if (maxVal <= 600) return 650;
    if (maxVal <= 1200) return 1300;
    if (maxVal <= 5000) return 5500;
    if (maxVal <= 15000) return 16000;
    return Math.ceil(maxVal * 1.15);
  }, [visibleSubjects]);

  // Generate ruler tick marks based on ceiling
  const rulerTicks = useMemo(() => {
    let step = 25;
    if (ceilingCm > 20000) step = 5000;
    else if (ceilingCm > 5000) step = 1000;
    else if (ceilingCm > 1500) step = 500;
    else if (ceilingCm > 500) step = 100;
    else if (ceilingCm > 300) step = 50;
    else if (ceilingCm > 150) step = 25;
    else step = 10;

    const ticks: { cm: number; percent: number; isMajor: boolean }[] = [];
    for (let cm = 0; cm <= ceilingCm; cm += step) {
      const percent = (cm / ceilingCm) * 100;
      ticks.push({
        cm,
        percent,
        isMajor: cm % (step * 2) === 0 || cm === 0,
      });
    }
    return ticks;
  }, [ceilingCm]);

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().then(() => setIsFullscreen(true)).catch(() => {});
    } else {
      document.exitFullscreen().then(() => setIsFullscreen(false)).catch(() => {});
    }
  };

  // Canvas background class helper
  const getBgClass = () => {
    switch (settings.background) {
      case 'blueprint':
        return 'bg-canvas-blueprint';
      case 'dark':
        return 'bg-canvas-dark';
      case 'horizon':
        return 'bg-canvas-horizon';
      case 'warm':
        return 'bg-canvas-warm';
      case 'neutral':
      default:
        return 'bg-canvas-neutral';
    }
  };

  const handleZoom = (delta: number) => {
    const next = Math.min(2.5, Math.max(0.5, Number((settings.zoom + delta).toFixed(1))));
    onUpdateSettings({ zoom: next });
  };

  const handleResetZoom = () => {
    onUpdateSettings({ zoom: 1 });
  };

  return (
    <div
      ref={containerRef}
      className={`relative flex flex-col rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900 transition-all ${
        isFullscreen ? 'fixed inset-0 z-50 rounded-none' : 'w-full'
      }`}
    >
      {/* Canvas Top Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 px-4 py-2.5 dark:border-slate-800 bg-white dark:bg-slate-900">
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
            Interactive Canvas
          </span>
          <span className="text-slate-300 dark:text-slate-700">·</span>
          <span className="text-xs font-medium text-slate-600 dark:text-slate-300">
            Scale: {ceilingCm >= 1000 ? `${(ceilingCm / 100).toFixed(0)}m` : `${ceilingCm} cm`} ceiling
          </span>
        </div>

        {/* Canvas Controls */}
        <div className="flex items-center gap-1.5 flex-wrap">
          {/* Background selector */}
          <div className="flex items-center gap-1 border-r border-slate-200 pr-2 mr-1 dark:border-slate-800">
            <button
              onClick={() => onUpdateSettings({ background: 'neutral' })}
              className={`h-6 w-6 rounded border transition-all ${
                settings.background === 'neutral'
                  ? 'border-indigo-600 ring-2 ring-indigo-500/20'
                  : 'border-slate-300 dark:border-slate-700'
              } bg-slate-100`}
              title="Studio Neutral Background"
            />
            <button
              onClick={() => onUpdateSettings({ background: 'blueprint' })}
              className={`h-6 w-6 rounded border transition-all ${
                settings.background === 'blueprint'
                  ? 'border-sky-500 ring-2 ring-sky-500/20'
                  : 'border-slate-300 dark:border-slate-700'
              } bg-slate-900`}
              title="Blueprint Grid Background"
            />
            <button
              onClick={() => onUpdateSettings({ background: 'horizon' })}
              className={`h-6 w-6 rounded border transition-all ${
                settings.background === 'horizon'
                  ? 'border-emerald-500 ring-2 ring-emerald-500/20'
                  : 'border-slate-300 dark:border-slate-700'
              } bg-gradient-to-b from-sky-200 to-emerald-200`}
              title="Outdoor Horizon Background"
            />
            <button
              onClick={() => onUpdateSettings({ background: 'warm' })}
              className={`h-6 w-6 rounded border transition-all ${
                settings.background === 'warm'
                  ? 'border-amber-500 ring-2 ring-amber-500/20'
                  : 'border-slate-300 dark:border-slate-700'
              } bg-amber-50`}
              title="Warm Architectural Background"
            />
          </div>

          {/* Grid toggle */}
          <button
            onClick={() => onUpdateSettings({ showGrid: !settings.showGrid })}
            className={`flex h-8 items-center gap-1 px-2.5 text-xs font-medium rounded-lg border transition-colors ${
              settings.showGrid
                ? 'border-indigo-200 bg-indigo-50 text-indigo-700 dark:border-indigo-900 dark:bg-indigo-950/40 dark:text-indigo-300'
                : 'border-slate-200 text-slate-600 hover:bg-slate-100 dark:border-slate-800 dark:text-slate-400 dark:hover:bg-slate-800'
            }`}
            title="Toggle Grid Lines"
          >
            <Grid className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Grid</span>
          </button>

          {/* Rulers Dual/Metric toggle */}
          <button
            onClick={() => {
              const next = settings.rulerUnit === 'dual' ? 'metric' : settings.rulerUnit === 'metric' ? 'imperial' : 'dual';
              onUpdateSettings({ rulerUnit: next });
            }}
            className="flex h-8 items-center gap-1 px-2.5 text-xs font-medium rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-100 dark:border-slate-800 dark:text-slate-400 dark:hover:bg-slate-800 transition-colors"
            title="Cycle Ruler Units (Dual / Metric / Imperial)"
          >
            <Layers className="h-3.5 w-3.5" />
            <span className="capitalize">{settings.rulerUnit}</span>
          </button>

          {/* Zoom In/Out/Reset */}
          <div className="flex items-center rounded-lg border border-slate-200 bg-slate-50 dark:border-slate-800 dark:bg-slate-800/60 p-0.5">
            <button
              onClick={() => handleZoom(-0.1)}
              className="p-1 rounded text-slate-600 hover:bg-white dark:text-slate-300 dark:hover:bg-slate-700"
              title="Zoom Out"
            >
              <ZoomOut className="h-3.5 w-3.5" />
            </button>
            <button
              onClick={handleResetZoom}
              className="px-1.5 text-xs font-mono font-medium text-slate-700 dark:text-slate-300"
              title="Reset Zoom to 100%"
            >
              {Math.round(settings.zoom * 100)}%
            </button>
            <button
              onClick={() => handleZoom(0.1)}
              className="p-1 rounded text-slate-600 hover:bg-white dark:text-slate-300 dark:hover:bg-slate-700"
              title="Zoom In"
            >
              <ZoomIn className="h-3.5 w-3.5" />
            </button>
          </div>

          {/* Fullscreen */}
          <button
            onClick={toggleFullscreen}
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-100 dark:border-slate-800 dark:text-slate-400 dark:hover:bg-slate-800 transition-colors"
            title={isFullscreen ? 'Exit Fullscreen' : 'View Fullscreen'}
          >
            {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
          </button>
        </div>
      </div>

      {/* Main Chart Canvas Area */}
      <div
        className={`relative flex-1 overflow-x-auto overflow-y-hidden ${getBgClass()} transition-colors print-area`}
        style={{
          minHeight: isFullscreen ? 'calc(100vh - 120px)' : '520px',
        }}
      >
        {/* If empty state */}
        {visibleSubjects.length === 0 ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-600 dark:bg-indigo-950/50 dark:text-indigo-400 mb-4 shadow-sm">
              <Sparkles className="h-7 w-7" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">
              Your Comparison Canvas is Empty
            </h3>
            <p className="mt-1 max-w-md text-sm text-slate-500 dark:text-slate-400">
              Add people with custom heights and silhouettes, or load objects and celebrities from the library.
            </p>
            <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
              <button
                onClick={onOpenAddPerson}
                className="inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-4 py-2.5 text-xs font-semibold text-white shadow-sm hover:bg-indigo-700 transition-colors"
              >
                + Add Custom Person
              </button>
              <button
                onClick={onOpenPresets}
                className="inline-flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-xs font-semibold text-slate-700 shadow-sm hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 transition-colors"
              >
                Browse Preset Library
              </button>
              <button
                onClick={() => onLoadLineup('average_worldwide')}
                className="inline-flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-xs font-semibold text-slate-700 shadow-sm hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 transition-colors"
              >
                Load Sample Lineup
              </button>
            </div>
          </div>
        ) : (
          <div
            className="relative flex h-full min-w-full pb-20 pt-16 transition-all duration-300 ease-out"
            style={{
              transform: `scale(${settings.zoom})`,
              transformOrigin: 'bottom center',
              width: `${Math.max(100, visibleSubjects.length * 160 + 180)}px`,
              height: '520px',
            }}
          >
            {/* Left Ruler */}
            {settings.showRulerLeft && (
              <div className="sticky left-0 z-20 flex h-full w-20 shrink-0 flex-col justify-end border-r border-slate-300/80 bg-white/80 dark:border-slate-700/80 dark:bg-slate-900/80 backdrop-blur-xs select-none">
                {rulerTicks.map((tick) => (
                  <div
                    key={tick.cm}
                    className="absolute right-0 flex items-center gap-1.5"
                    style={{ bottom: `${tick.percent}%` }}
                  >
                    <div className="text-right font-mono text-[10px] leading-none text-slate-500 dark:text-slate-400">
                      {settings.rulerUnit !== 'imperial' && <span>{tick.cm}cm</span>}
                      {settings.rulerUnit === 'dual' && <span className="mx-1 text-slate-300">·</span>}
                      {settings.rulerUnit !== 'metric' && (
                        <span>{cmToFeetAndInches(tick.cm).formatted}</span>
                      )}
                    </div>
                    <div
                      className={`h-[1px] ${
                        tick.isMajor
                          ? 'w-3 bg-slate-500 dark:bg-slate-400'
                          : 'w-1.5 bg-slate-300 dark:bg-slate-600'
                      }`}
                    />
                  </div>
                ))}
              </div>
            )}

            {/* Horizontal Grid lines across entire canvas */}
            {settings.showGrid && (
              <div className="pointer-events-none absolute inset-x-0 inset-y-0 pb-20 pt-16">
                {rulerTicks.map((tick) => (
                  <div
                    key={`grid_${tick.cm}`}
                    className={`absolute inset-x-0 border-b ${
                      tick.isMajor
                        ? 'border-slate-300/40 dark:border-slate-700/40'
                        : 'border-slate-200/30 dark:border-slate-800/30'
                    }`}
                    style={{ bottom: `${tick.percent}%` }}
                  />
                ))}
              </div>
            )}

            {/* Figures Display Container */}
            <div className="relative flex flex-1 items-end justify-center gap-6 px-8 z-10">
              {visibleSubjects.map((subject, index) => {
                const heightPercent = (subject.heightCm / ceilingCm) * 100;
                const isHovered = hoveredSubjectId === subject.id;
                const bothUnits = formatBothUnits(subject.heightCm);

                // Proportional width calculation
                // Wider for animals/vehicles/furniture; standard for human figures
                const isWideObject = ['car', 'bus', 'couch', 'horse', 'elephant', 'table'].includes(
                  subject.objectPresetKey || ''
                );
                const figureWidthPx = isWideObject ? 180 : 100;

                return (
                  <div
                    key={subject.id}
                    onMouseEnter={() => setHoveredSubjectId(subject.id)}
                    onMouseLeave={() => setHoveredSubjectId(null)}
                    className="group relative flex flex-col items-center justify-end transition-transform hover:z-30"
                    style={{
                      height: '100%',
                      width: `${figureWidthPx}px`,
                    }}
                  >
                    {/* Top Floating Height Badge */}
                    {settings.showHeightLabels && (
                      <div
                        className="absolute z-20 flex flex-col items-center pointer-events-none transition-all duration-150"
                        style={{
                          bottom: `calc(${heightPercent}% + 8px)`,
                        }}
                      >
                        <div className="flex items-center gap-1.5 rounded-lg border border-slate-200/90 bg-white/95 px-2 py-0.5 text-xs font-semibold text-slate-800 shadow-md backdrop-blur-xs dark:border-slate-700 dark:bg-slate-900/95 dark:text-slate-100 whitespace-nowrap">
                          <span className="font-mono text-[11px] tabular-nums">
                            {subject.heightCm >= 1000
                              ? `${(subject.heightCm / 100).toFixed(1)}m`
                              : `${subject.heightCm} cm`}
                          </span>
                          <span className="text-slate-300 dark:text-slate-600">·</span>
                          <span className="font-mono text-[11px] text-slate-500 dark:text-slate-400">
                            {bothUnits.imperial}
                          </span>
                        </div>
                        {/* Little pointer triangle */}
                        <div className="h-1.5 w-1.5 rotate-45 border-b border-r border-slate-200 bg-white dark:border-slate-700 dark:bg-slate-900 -mt-0.5" />
                      </div>
                    )}

                    {/* Figure Silhouette Body (proportional height, baseline anchored) */}
                    <div
                      className="relative w-full flex items-end justify-center transition-all duration-300"
                      style={{
                        height: `${heightPercent}%`,
                      }}
                    >
                      <SilhouetteRenderer subject={subject} />

                      {/* Hover action toolbar for this figure */}
                      {isHovered && (
                        <div className="absolute top-2 flex items-center gap-1 rounded-xl border border-slate-200 bg-white/95 p-1 shadow-lg dark:border-slate-700 dark:bg-slate-900/95 backdrop-blur-xs z-30 animate-in fade-in zoom-in-95 duration-100">
                          {index > 0 && (
                            <button
                              onClick={() => onMoveSubject(subject.id, 'left')}
                              className="rounded p-1 text-slate-500 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-white"
                              title="Move Left"
                            >
                              <ArrowLeft className="h-3.5 w-3.5" />
                            </button>
                          )}
                          {index < visibleSubjects.length - 1 && (
                            <button
                              onClick={() => onMoveSubject(subject.id, 'right')}
                              className="rounded p-1 text-slate-500 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-white"
                              title="Move Right"
                            >
                              <ArrowRight className="h-3.5 w-3.5" />
                            </button>
                          )}
                          <button
                            onClick={() => onEditSubject(subject)}
                            className="rounded p-1 text-slate-500 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-white"
                            title="Edit Subject"
                          >
                            <Edit3 className="h-3.5 w-3.5" />
                          </button>
                          <button
                            onClick={() => onDuplicateSubject(subject)}
                            className="rounded p-1 text-slate-500 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-white"
                            title="Duplicate"
                          >
                            <Copy className="h-3.5 w-3.5" />
                          </button>
                          <button
                            onClick={() => onToggleSubjectVisibility(subject.id)}
                            className="rounded p-1 text-slate-500 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-white"
                            title="Hide"
                          >
                            <EyeOff className="h-3.5 w-3.5" />
                          </button>
                          <button
                            onClick={() => onDeleteSubject(subject.id)}
                            className="rounded p-1 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                            title="Remove"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      )}
                    </div>

                    {/* Figure Name Label (Below Ground Line) */}
                    {settings.showNameLabels && (
                      <div className="mt-3 flex flex-col items-center text-center select-none">
                        <span className="text-xs font-bold text-slate-900 dark:text-white max-w-[120px] truncate">
                          {subject.name}
                        </span>
                        <span className="text-[10px] text-slate-500 dark:text-slate-400 font-medium capitalize">
                          {subject.category}
                        </span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Right Ruler */}
            {settings.showRulerRight && (
              <div className="sticky right-0 z-20 flex h-full w-20 shrink-0 flex-col justify-end border-l border-slate-300/80 bg-white/80 dark:border-slate-700/80 dark:bg-slate-900/80 backdrop-blur-xs select-none">
                {rulerTicks.map((tick) => (
                  <div
                    key={`r_${tick.cm}`}
                    className="absolute left-0 flex items-center gap-1.5"
                    style={{ bottom: `${tick.percent}%` }}
                  >
                    <div
                      className={`h-[1px] ${
                        tick.isMajor
                          ? 'w-3 bg-slate-500 dark:bg-slate-400'
                          : 'w-1.5 bg-slate-300 dark:bg-slate-600'
                      }`}
                    />
                    <div className="text-left font-mono text-[10px] leading-none text-slate-500 dark:text-slate-400">
                      {settings.rulerUnit !== 'metric' && (
                        <span>{cmToFeetAndInches(tick.cm).formatted}</span>
                      )}
                      {settings.rulerUnit === 'dual' && <span className="mx-1 text-slate-300">·</span>}
                      {settings.rulerUnit !== 'imperial' && <span>{tick.cm}cm</span>}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Solid Ground Baseline */}
        {settings.showGroundLine && (
          <div className="absolute inset-x-0 bottom-20 z-15 flex items-center">
            <div className="h-1 w-full bg-indigo-600 dark:bg-indigo-500 shadow-sm" />
            <div className="absolute right-4 -top-5 rounded bg-indigo-600 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider text-white shadow-xs">
              Ground Baseline (0 cm)
            </div>
          </div>
        )}
      </div>

      {/* Canvas Bottom Quick-Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-200 bg-slate-50/80 px-4 py-2 text-xs text-slate-600 dark:border-slate-800 dark:bg-slate-900/80 dark:text-slate-400">
        <div className="flex items-center gap-2">
          <span>Active Figures: {visibleSubjects.length} of {subjects.length}</span>
          <span className="text-slate-300 dark:text-slate-700">·</span>
          <span className="flex items-center gap-1">
            <span className="h-2 w-2 rounded-full bg-emerald-500" />
            Shared baseline orthographic projection
          </span>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => onUpdateSettings({ showHeightLabels: !settings.showHeightLabels })}
            className="hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
          >
            {settings.showHeightLabels ? 'Hide Heights' : 'Show Heights'}
          </button>
          <span>·</span>
          <button
            onClick={() => onUpdateSettings({ showNameLabels: !settings.showNameLabels })}
            className="hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
          >
            {settings.showNameLabels ? 'Hide Names' : 'Show Names'}
          </button>
        </div>
      </div>
    </div>
  );
};
