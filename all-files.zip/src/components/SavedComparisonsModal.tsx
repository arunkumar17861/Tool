import React from 'react';
import { X, Bookmark, Trash2, FolderOpen, Calendar, ArrowRight } from 'lucide-react';
import { SavedComparison } from '../types';

interface SavedComparisonsModalProps {
  isOpen: boolean;
  onClose: () => void;
  savedList: SavedComparison[];
  onLoadComparison: (saved: SavedComparison) => void;
  onDeleteSaved: (id: string) => void;
}

export const SavedComparisonsModal: React.FC<SavedComparisonsModalProps> = ({
  isOpen,
  onClose,
  savedList,
  onLoadComparison,
  onDeleteSaved,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div 
        className="relative w-full max-w-lg flex flex-col rounded-2xl bg-white shadow-2xl dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600 dark:bg-indigo-950/50 dark:text-indigo-400">
              <Bookmark className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                Saved Comparisons
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Load or manage your locally saved lineups
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800 dark:hover:text-slate-200 transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* List */}
        <div className="max-h-96 overflow-y-auto p-4 space-y-2">
          {savedList.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-400">
              No saved comparisons yet. Click &quot;Share & Export&quot; to save your current chart.
            </div>
          ) : (
            savedList.map((item) => (
              <div
                key={item.id}
                className="flex items-center justify-between gap-3 rounded-xl border border-slate-200 p-3 hover:border-indigo-300 dark:border-slate-800 dark:hover:border-indigo-900 transition-all"
              >
                <div className="min-w-0 flex-1">
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white truncate">
                    {item.title}
                  </h4>
                  <div className="mt-1 flex items-center gap-2 text-[11px] text-slate-500">
                    <span>{item.subjects.length} figures</span>
                    <span>·</span>
                    <span className="flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      {new Date(item.savedAt).toLocaleDateString()}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={() => {
                      onLoadComparison(item);
                      onClose();
                    }}
                    className="inline-flex items-center gap-1 rounded-lg bg-indigo-50 px-2.5 py-1.5 text-xs font-semibold text-indigo-700 hover:bg-indigo-600 hover:text-white dark:bg-indigo-950/50 dark:text-indigo-300 dark:hover:bg-indigo-600 dark:hover:text-white transition-colors"
                  >
                    <FolderOpen className="h-3.5 w-3.5" />
                    Load
                  </button>
                  <button
                    onClick={() => onDeleteSaved(item.id)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 dark:hover:text-rose-400"
                    title="Delete Saved Comparison"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end border-t border-slate-200 px-6 py-3.5 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50">
          <button
            onClick={onClose}
            className="rounded-xl px-4 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-200/60 dark:text-slate-300 dark:hover:bg-slate-800 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
