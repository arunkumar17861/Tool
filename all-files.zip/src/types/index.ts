export type SubjectCategory = 'person' | 'object' | 'animal' | 'landmark' | 'custom' | 'vehicle';

export type GenderStyle = 
  | 'male' 
  | 'female' 
  | 'athletic_male' 
  | 'athletic_female' 
  | 'teen' 
  | 'child' 
  | 'toddler'
  | 'neutral';

export type CustomShapeType = 'rect' | 'cylinder' | 'circle';

export interface ComparisonSubject {
  id: string;
  name: string;
  heightCm: number;
  category: SubjectCategory;
  genderStyle?: GenderStyle;
  objectPresetKey?: string;
  color: string;
  customImageUrl?: string;
  customShape?: CustomShapeType;
  customWidthCm?: number;
  notes?: string;
  source?: string;
  isVerified?: boolean;
  isVisible: boolean;
}

export type UnitPreference = 'cm' | 'm' | 'ft_in' | 'in';

export type CanvasBackground = 'neutral' | 'blueprint' | 'dark' | 'horizon' | 'warm';

export interface CanvasSettings {
  showGrid: boolean;
  showRulerLeft: boolean;
  showRulerRight: boolean;
  showHeightLabels: boolean;
  showNameLabels: boolean;
  showGroundLine: boolean;
  rulerUnit: 'dual' | 'metric' | 'imperial';
  background: CanvasBackground;
  zoom: number; // 0.5 to 2.5
  panOffset: number;
}

export interface PresetItem {
  id: string;
  name: string;
  category: 'celebrity' | 'athlete' | 'historical' | 'fictional' | 'animal' | 'everyday' | 'vehicle' | 'landmark';
  heightCm: number;
  genderStyle?: GenderStyle;
  objectPresetKey?: string;
  defaultColor: string;
  description: string;
  source?: string;
  isVerified?: boolean;
  tag?: string;
}

export interface SavedComparison {
  id: string;
  title: string;
  savedAt: number;
  subjects: ComparisonSubject[];
}

export interface HeightDifferenceResult {
  diffCm: number;
  diffInches: number;
  diffFeetIn: string;
  ratio: number;
  percentDiff: number;
  tallerSubject: ComparisonSubject;
  shorterSubject: ComparisonSubject;
}
